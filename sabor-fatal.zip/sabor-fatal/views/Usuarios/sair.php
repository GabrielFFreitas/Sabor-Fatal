<?php
session_start();
require_once "../../vendors/Security/Security.php";
Security::exit();

