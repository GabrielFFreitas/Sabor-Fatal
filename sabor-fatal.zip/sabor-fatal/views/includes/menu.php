<div class="col-3 menu">
    <nav class="nav flex-column nav-pills">
        <a class="nav-link" href="../Home/">Home</a>
        <a class="nav-link" href="../Categorias/">Categorias</a>
        <a class="nav-link" href="../Clientes/">Clientes</a>
        <a class="nav-link" href="../Produtos/">Produtos</a>
        <a class="nav-link" href="../Jogos/">Jogos</a>
        <a class="nav-link" href="../Filmes/">Filmes</a>
        <a class="nav-link" href="../Usuarios/">Usuários</a>
        <a class="nav-link" href="../Usuarios/sair.php">Sair</a>
    </nav>
</div>