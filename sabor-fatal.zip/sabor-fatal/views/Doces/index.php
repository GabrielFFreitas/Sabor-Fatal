<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doces</title>
    <?php include '../includes/head.php' ?>
</head>
<body>
    <?php include '../includes/header.php' ?>

    <!-- PROMOÇÕES-->
    <div class="promocoes d-flex flex-inline justify-content-between">
        <div><img class="roscas-1" src="../../img/Cereja.svg" alt=""></div>
        <div class="promocoes-tittle text-center align-items-center d-flex f-w">
            <span>Promoções</br> do Dia</span>
        </div>
        <div><img class="roscas-2" src="../../img/Cereja (1).svg" alt=""></div>
    </div>


</body>
</html>